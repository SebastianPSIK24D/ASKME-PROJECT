<div class="flex items-center gap-3">
    <img src="{{ asset('img/ASKME.png') }}" alt="Logo ASKME" {{ $attributes->merge(['class' => 'h-12 w-auto']) }}>
    <img src="{{ asset('img/UNIMED.png') }}" alt="Logo UNIMED" {{ $attributes->merge(['class' => 'h-12 w-auto']) }}>
</div>
